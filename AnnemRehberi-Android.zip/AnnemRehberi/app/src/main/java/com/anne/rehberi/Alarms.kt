package com.anne.rehberi
import android.app.*
import android.content.*
import java.util.Calendar
object Alarms{
 fun prefs(c:Context)=c.getSharedPreferences("alarms",0)
 fun pi(c:Context,id:String,msg:String)=PendingIntent.getBroadcast(c,id.hashCode(),Intent(c,AlarmReceiver::class.java).putExtra("id",id).putExtra("msg",msg),PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
 fun set(c:Context,id:String,h:Int,m:Int,msg:String){prefs(c).edit().putString(id,"$h|$m|$msg").apply();schedule(c,id,h,m,msg)}
 fun cancel(c:Context,id:String){prefs(c).edit().remove(id).apply();c.getSystemService(AlarmManager::class.java).cancel(pi(c,id,""))}
 fun schedule(c:Context,id:String,h:Int,m:Int,msg:String){
  val t=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,h);set(Calendar.MINUTE,m);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0);if(timeInMillis<=System.currentTimeMillis())add(Calendar.DAY_OF_MONTH,1)}
  val show=PendingIntent.getActivity(c,0,Intent(c,MainActivity::class.java),PendingIntent.FLAG_IMMUTABLE)
  c.getSystemService(AlarmManager::class.java).setAlarmClock(AlarmManager.AlarmClockInfo(t.timeInMillis,show),pi(c,id,msg))}
 fun all(c:Context){prefs(c).all.forEach{(k,v)->val p=(v as String).split("|",limit=3);schedule(c,k,p[0].toInt(),p[1].toInt(),p[2])}}
}
class BootReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){Alarms.all(c)}}
