package com.anne.rehberi
import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.graphics.*
import android.hardware.camera2.*
import android.os.*
import android.util.Base64
import android.webkit.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import org.json.*
import java.io.ByteArrayOutputStream

class MainActivity:AppCompatActivity(){
 lateinit var web:WebView
 override fun onCreate(s:Bundle?){
  super.onCreate(s)
  if(Build.VERSION.SDK_INT>=33)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),1)
  web=WebView(this);setContentView(web)
  web.settings.apply{javaScriptEnabled=true;domStorageEnabled=true;mediaPlaybackRequiresUserGesture=false}
  web.webViewClient=object:WebViewClient(){
   override fun shouldOverrideUrlLoading(v:WebView,r:WebResourceRequest):Boolean{
    val u=r.url.toString()
    if(u.startsWith("file:"))return false
    try{when{
     u.startsWith("app://")->packageManager.getLaunchIntentForPackage(u.removePrefix("app://"))?.let{startActivity(it)}
     u.startsWith("intent:")->startActivity(Intent.parseUri(u,Intent.URI_INTENT_SCHEME))
     u.startsWith("tel:")->startActivity(Intent(Intent.ACTION_DIAL,r.url))
     else->startActivity(Intent(Intent.ACTION_VIEW,r.url))}}catch(e:Exception){}
    return true}}
  web.webChromeClient=object:WebChromeClient(){
   override fun onJsConfirm(v:WebView,u:String,m:String,r:JsResult):Boolean{
    AlertDialog.Builder(this@MainActivity).setMessage(m).setPositiveButton("Evet"){_,_->r.confirm()}.setNegativeButton("Hayır"){_,_->r.cancel()}.setOnCancelListener{r.cancel()}.show();return true}}
  web.addJavascriptInterface(Bridge(),"Android")
  web.loadUrl("file:///android_asset/index.html")
  onBackPressedDispatcher.addCallback(this,object:OnBackPressedCallback(true){override fun handleOnBackPressed(){
   web.evaluateJavascript("(function(){if(view!=='home'){go('home');return 1}return 0})()"){if(it!="1")finish()}}})
 }
 inner class Bridge{
  @JavascriptInterface fun getApps():String{
   val pm=packageManager;val arr=JSONArray()
   val l=pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),0).distinctBy{it.activityInfo.packageName}.sortedBy{it.loadLabel(pm).toString().lowercase()}
   for(r in l){val p=r.activityInfo.packageName;if(p==packageName)continue
    val d=r.loadIcon(pm);val b=Bitmap.createBitmap(72,72,Bitmap.Config.ARGB_8888);d.setBounds(0,0,72,72);d.draw(Canvas(b))
    val o=ByteArrayOutputStream();b.compress(Bitmap.CompressFormat.PNG,100,o)
    arr.put(JSONObject().put("n",r.loadLabel(pm).toString()).put("p",p).put("i","data:image/png;base64,"+Base64.encodeToString(o.toByteArray(),Base64.NO_WRAP)))}
   return arr.toString()}
  @JavascriptInterface fun torch(on:Boolean):Boolean=try{
   val cm=getSystemService(CameraManager::class.java)
   val id=cm.cameraIdList.first{cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE)==true}
   cm.setTorchMode(id,on);true}catch(e:Exception){false}
  @JavascriptInterface fun setAlarm(id:String,h:Int,m:Int,msg:String){Alarms.set(this@MainActivity,id,h,m,msg)}
  @JavascriptInterface fun cancelAlarm(id:String){Alarms.cancel(this@MainActivity,id)}
 }
}
