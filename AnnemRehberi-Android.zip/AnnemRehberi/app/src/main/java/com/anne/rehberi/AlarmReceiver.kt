package com.anne.rehberi
import android.app.*
import android.content.*
import android.media.*
class AlarmReceiver:BroadcastReceiver(){
 override fun onReceive(c:Context,i:Intent){
  val id=i.getStringExtra("id")?:return
  val p=Alarms.prefs(c).getString(id,null)?:return
  val q=p.split("|",limit=3)
  Alarms.schedule(c,id,q[0].toInt(),q[1].toInt(),q[2])
  val nm=c.getSystemService(NotificationManager::class.java)
  val ch=NotificationChannel("ilac","İlaç alarmı",NotificationManager.IMPORTANCE_HIGH)
  ch.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
  ch.enableVibration(true);ch.vibrationPattern=longArrayOf(0,600,300,600,300,600)
  nm.createNotificationChannel(ch)
  val open=PendingIntent.getActivity(c,1,Intent(c,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),PendingIntent.FLAG_IMMUTABLE)
  val n=Notification.Builder(c,"ilac").setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("💊 İlaç saati").setContentText(q[2]).setCategory(Notification.CATEGORY_ALARM).setFullScreenIntent(open,true).setContentIntent(open).setAutoCancel(true).build()
  n.flags=n.flags or Notification.FLAG_INSISTENT
  nm.notify(id.hashCode(),n)
 }
}
